package com.assistant.writer.controller;

import com.assistant.writer.model.EmailRequest;
import com.assistant.writer.service.EmailGeneratorService;
import lombok.AllArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/toEmail")
@AllArgsConstructor
@CrossOrigin(origins = "*")
public class EmailAssistController {

    private final EmailGeneratorService emailGeneratorService;

    @PostMapping
    public ResponseEntity<String> generateEmail(@RequestBody EmailRequest emailRequest) {
        String response = emailGeneratorService.generateReply(emailRequest);
        return ResponseEntity.ok(response);
    }
}
